export interface ILogInEntity{
  login:string
  password: string
}


  