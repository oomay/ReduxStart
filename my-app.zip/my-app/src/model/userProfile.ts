export interface IUserProfile{
     id:number;
     userName:string;
}