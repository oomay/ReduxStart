export interface IUserEntity {
   firstname:string
   lastname:string
   email:string
   password:string
   id:number
}
